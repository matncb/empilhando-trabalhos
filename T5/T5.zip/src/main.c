#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <list.h>
#include <ui.h>


int main()
{
    ui_run();
    return 0;
}