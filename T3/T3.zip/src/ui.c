#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <stack.h>
#include <ui.h>

int ui_get_top_2(Stack *stack, float *top_item1, float *top_item2)
{
    if (stack->top <= 1)
    {
        printf("Not enough elements \n");
        return 1;
    }

    stack_pop(stack, top_item1);
    stack_pop(stack, top_item2);

    return 0;
}

void ui_push_number(Stack *stack, float number)
{
    stack_push(stack, number);
    return;
}

void ui_sum_numbers(Stack *stack)
{
    float top_item1, top_item2;
    if (ui_get_top_2(stack, &top_item1, &top_item2))
    {
        return;
    }

    float sum = top_item1 + top_item2;
    stack_push(stack, sum);

    printf("%.2f\n", sum);
}

void ui_subtract_numbers(Stack *stack)
{
    float top_item1, top_item2;
    if (ui_get_top_2(stack, &top_item1, &top_item2))
    {
        return;
    }

    float diff = top_item2 - top_item1;
    stack_push(stack, diff);

    printf("%.2f\n", diff);
}

void ui_multiply_numbers(Stack *stack)
{
    float top_item1, top_item2;
    if (ui_get_top_2(stack, &top_item1, &top_item2))
    {
        return;
    }

    float mul = (top_item1 * top_item2);
    stack_push(stack, mul);

    printf("%.2f\n", mul);
}

void ui_divide_numbers(Stack *stack)
{
    float top_item1, top_item2;
    if (ui_get_top_2(stack, &top_item1, &top_item2))
    {
        return;
    }

    float div = top_item2 / top_item1;
    stack_push(stack, div);

    printf("%.2f\n", div);
}

void ui_exp_numbers(Stack *stack)
{
    float top_item1, top_item2;
    if (ui_get_top_2(stack, &top_item1, &top_item2))
    {
        return;
    }

    float exp = pow(top_item2, top_item1);
    stack_push(stack, exp);

    printf("%.2f\n", exp);
}

void ui_list(Stack *stack)
{
    float item;

    while ((!stack_is_empty(stack)))
    {
        stack_pop(stack, &item);
        printf("%.2f ", item);
    }

}

void ui_run()
{
    bool loop = true;
    char command[INPT_CMD_MAX_LENGTH];

    Stack *stack = stack_create_empty();
    if (!stack) exit(1);

    while (loop)
    {
        scanf("%s", command);
        if (strcmp(command, "+") == 0)
        {
            ui_sum_numbers(stack);
        }
        else if (strcmp(command, "-") == 0)
        {
            ui_subtract_numbers(stack);
        }
        else if (strcmp(command, "*") == 0)
        {
            ui_multiply_numbers(stack);
        }
        else if (strcmp(command, "^") == 0)
        {
            ui_exp_numbers(stack);
        }
        else if (strcmp(command, "/") == 0)
        {
            ui_divide_numbers(stack);
        } else if (strcmp(command, "off") == 0)
        {
            loop = false;
            printf("Pilha: ");
            ui_list(stack);
            printf("\n");
        }
        else 
        {
            ui_push_number(stack, atof(command));
        }
    }

    free(stack);

    return;
}